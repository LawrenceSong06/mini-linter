"""
上次修改时间: 2026-07-14-22:55
上次修改内容: Restore UTF-8 file header metadata
上次修改者: Agent Joe
文件设计: Forbidden import sample
文件功能: Provide a program that uses an allowed import.
文件创建者: Agent Joe
"""

import sys

VALUE = sys.version_info.major
